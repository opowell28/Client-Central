-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 12, 2022 at 04:54 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `phplogin`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `appt_id` int(11) NOT NULL,
  `patient_username` varchar(50) NOT NULL,
  `docname` varchar(50) NOT NULL,
  `date` varchar(13) NOT NULL,
  `time` varchar(10) NOT NULL,
  `symptoms` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`appt_id`, `patient_username`, `docname`, `date`, `time`, `symptoms`) VALUES
(11, 'andykuziel', 'Sharkey', '12/10/2022', '10:00 AM', 'Annual Checkup'),
(12, 'andrewkuziel', 'Sharkeyy', '12/10/2022', '10:00 AM', 'Annual Checkup'),
(13, 'andykuziel', 'Sharkey', '12/10/2022', '12:00 PM', 'Running nose, nausea, chills'),
(14, 'maxwell', 'Sharkey', '12/11/2022', '9:00 AM', 'coughing; runny nose '),
(15, 'maxwell', 'andrew', '12/11/2022', '10:00 AM', 'cough');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_accounts`
--

CREATE TABLE `doctor_accounts` (
  `doctor_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `doctor_accounts`
--

INSERT INTO `doctor_accounts` (`doctor_id`, `username`, `password`, `email`) VALUES
(6, 'Sharkey', '$2y$10$ApYsJT.IzS/OpcwXe3.ZROiqRpcmASOT7MLPWAKBHvm5lyxhIIZCe', 'jbs@test.com');

-- --------------------------------------------------------

--
-- Table structure for table `patient_accounts`
--

CREATE TABLE `patient_accounts` (
  `patient_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `patient_accounts`
--

INSERT INTO `patient_accounts` (`patient_id`, `username`, `password`, `email`) VALUES
(12, 'andykuziel', '$2y$10$cdl4fFMRDdFgJeXSEKVxeOKM6gHLVc8l8iQ4yB22bDUfGFdetLqqO', 'andykuziel@test.com'),
(13, 'owenpowell', '$2y$10$/agQLXkF6590uMY/KqI/vOwryDXUJqkxwYD1mfHEqIuUhbp/SkMXW', 'o@cc.com'),
(14, 'jlewis', '$2y$10$RyfVREEw5e8yvxmBM7GjVeuQZCxlDzBYtd5sV8AEZtQY/h0sl55am', 'j@cc.com'),
(15, 'maxwell', '$2y$10$BmsHFjbcUxwjSsy0TPJF6ed1kWlgBVNPfWcXCgvB/23YMbN2WxtbK', 'max@cc.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`appt_id`);

--
-- Indexes for table `doctor_accounts`
--
ALTER TABLE `doctor_accounts`
  ADD PRIMARY KEY (`doctor_id`);

--
-- Indexes for table `patient_accounts`
--
ALTER TABLE `patient_accounts`
  ADD PRIMARY KEY (`patient_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `appt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `doctor_accounts`
--
ALTER TABLE `doctor_accounts`
  MODIFY `doctor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `patient_accounts`
--
ALTER TABLE `patient_accounts`
  MODIFY `patient_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
